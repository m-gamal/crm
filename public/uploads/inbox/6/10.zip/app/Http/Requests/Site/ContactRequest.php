<?php

namespace App\Http\Requests\Site;

use App\Http\Requests\Request;

class ContactRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'      =>  'required',
            'phone'     =>  'required|numeric',
            'email'     =>  'required|email',
            'message'   =>  'required'
        ];
    }

    public function messages()
    {
        return [
            'name.required'             => 'الإسم مطلوب',
            'phone.required'            =>  'رقم التليفون مطلوب',
            'phone.numeric'             =>  'رقم التليفون يجب ان يكون ارقام',
            'email.required'            =>  'البريد الإلكترونى مطلوب',
            'email.unique'              =>  'البريد الإلكترونى موجود من قبل',
            'message.required'          =>  'الرسالة مطلوبة'
        ];
    }
}
