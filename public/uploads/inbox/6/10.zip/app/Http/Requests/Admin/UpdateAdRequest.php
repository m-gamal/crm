<?php

namespace App\Http\Requests\Admin;

use App\Http\Requests\Request;

class UpdateAdRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title'             =>  'required',
            'representative'    =>  'required',
            'description'       =>  'required',
            'phone'             =>  'numeric',
            'mobile'            =>  'numeric',
            'email'             =>  'email',
            'website'           =>  '',
            'category'          =>  'required',
            'period'            =>  'required',
            'offer'             =>  'required',
            'city'              =>  'required',
            'position'          =>  'required',
            'address'           =>  '',
            'is_featured'       =>  'required',
            'pic1'              =>  'mimes:jpeg',
            'pic2'              =>  'mimes:jpeg',
            'pic3'              =>  'mimes:jpeg',
            'pic4'              =>  'mimes:jpeg',
            'pic5'              =>  'mimes:jpeg',
        ];
    }

    public function messages()
    {
        return [
            'title.required'            => 'العنوان مطلوب',
            'representative.required'   =>  'إسم المندوب المسئول مطلوب',
            'description.required'      =>  'وصف الإعلان مطلوب',
            'phone.required'            =>  'رقم التليفون مطلوب',
            'mobile.required'           =>  'رقم الجوال مطلوب',
            'email.required'            =>  'البريد الإلكترونى مطلوب',
            'category.required'         =>  'الفئة مطلوبة',
            'period.required'           =>  'مدة الإعلان مطلوبة',
            'offer.required'            =>  'عروض الإعلان مطلوبة',
            'city.required'             =>  'المدينة مطلوبة',
            'position.required'         =>  'موقع الإعلان مطلوب',
            'is_featured.required'      =>  'نوع الإعلان مطلوب',
            'pic1.mimes'                => 'نوع الصورة يجب ان يكون JPG'
        ];
    }
}
