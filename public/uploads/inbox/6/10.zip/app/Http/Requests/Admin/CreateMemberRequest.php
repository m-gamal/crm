<?php

namespace App\Http\Requests\Admin;

use App\Http\Requests\Request;

class CreateMemberRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'full_name' =>  'required',
            'username'  =>  'required|unique:member,username',
            'email'     =>  'required|email|unique:member,email',
            'password'  =>  'required|confirmed'
        ];
    }

    public function messages()
    {
        return [
            'full_name.required'    => 'الإسم مطلوب',
            'username.required'     =>  'إسم المستخدم مطلوب',
            'username.unique'       =>  'إسم المستخدم موجود من قبل',
            'email.required'        =>  'البريد الإلكترونى مطلوب',
            'email.email'           =>  'صيغة البريد الإلكترونى غير صحيحة',
            'email.unique'          =>  'البريد الإلكترونى موجود من قبل',
            'password.required'     =>  'كلمة المرور مطلوبة',
            'password.confirmed'    =>  'كلمة المرور التى ادخلتها لا تطابق كلمة المرور الاصلية'
        ];
    }
}
