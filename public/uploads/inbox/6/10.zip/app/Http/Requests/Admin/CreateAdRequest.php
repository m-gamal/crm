<?php

namespace App\Http\Requests\Admin;

use App\Http\Requests\Request;

class CreateAdRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            
        ];
    }

    public function messages()
    {
        return [
            'title.required'            => 'العنوان مطلوب',
            'representative.required'   =>  'إسم المندوب المسئول مطلوب',
            'description.required'      =>  'وصف الإعلان مطلوب',
            'number.required'           =>  'رقم السند مطلوب',
            'number.numeric'            =>  'رقم السند يجب ان يكون ارقام فقط',
            'number.unique'             =>  'رقم السند موجود من قبل',
            'phone.required'            =>  'رقم التليفون مطلوب',
            'phone.unique'              =>  'رقم التليفون موجود من قبل',
            'mobile.required'           =>  'رقم الجوال مطلوب',
            'mobile.unique'             =>  'رقم الجوال موجود من قبل',
            'email.required'            =>  'البريد الإلكترونى مطلوب',
            'email.unique'              =>  'البريد الإلكترونى موجود من قبل',
            'category.required'         =>  'الفئة مطلوبة',
            'period.required'           =>  'مدة الإعلان مطلوبة',
            'offer.required'            =>  'عروض الإعلان مطلوبة',
            'city.required'             =>  'المدينة مطلوبة',
            'position.required'         =>  'موقع الإعلان مطلوب',
            'is_featured.required'      =>  'نوع الإعلان مطلوب',
            'pic1.mimes'                => 'نوع الصورة يجب ان يكون JPG'
        ];
    }
}
