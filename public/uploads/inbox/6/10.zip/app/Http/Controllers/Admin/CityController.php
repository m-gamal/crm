<?php

namespace App\Http\Controllers\Admin;

use App\City;
use App\Http\Requests\Admin\CityRequest;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class CityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cities = City::all();
        $dataView   =   [
            'cities'    =>  $cities
        ];
        return view('admin.city.all', $dataView);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * @param CityRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(CityRequest $request)
    {
        $city = new City;
        $city->name = $request->name;

        try {
            $city->save();
            return redirect()->back()->with('message','تم إضافة المدينة بنجاح ');
        } catch (ParseException $ex) {
            echo 'خطأ فى إضافة المدينة ، من فضلك قم بالمراجعة مرة اخرى';
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * @param CityRequest $request
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(CityRequest $request, $id)
    {
        $singleCity = City::findOrFail($id);
        $singleCity->name = $request->name;
        try {
            $singleCity->save();
            return redirect()->back()->with('message','تم تعديل المدينة بنجاح');
        } catch (ParseException $ex) {
            echo 'خطا فى تعديل المدينة ، من فضلك قم بالمراجعة مرة اخرى';
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $singleCity = City::findOrFail($id);
        try {
            $singleCity->delete();
            return redirect()->back()->with('message','تم حذف المدينة بنجاح');
        } catch (ParseException $ex) {
            echo 'خطأ فى حذف المدينة ، من فضلك قم بالمراجعة مرة اخرى';
        }
    }
}
