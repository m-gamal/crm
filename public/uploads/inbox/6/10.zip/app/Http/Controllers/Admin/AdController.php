<?php

namespace App\Http\Controllers\Admin;

use App\Member;
use App\Http\Requests;
use App\Http\Requests\Admin\CreateAdRequest;
use App\Http\Requests\Admin\UpdateAdRequest;
use App\Http\Controllers\Controller;
use App\Ad;
use App\Category;
use App\City;
use Intervention\Image\ImageManager;

class AdController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $ads                = Ad::all();
        $representatives    = Member::where('level', 2)->get();
        $dataView           =   [
            'ads'               =>  $ads,
            'counter'           =>  0,
            'representatives'   =>  $representatives
        ];

        return view('admin.ad.all', $dataView);
    }

    public function catAds($catId)
    {
        $ads                = Ad::where('cat_id', $catId)->get();
        $representatives    = Member::where('level', 2)->get();
        $dataView           =   [
            'ads'               =>  $ads,
            'counter'           =>  0,
            'representatives'   =>  $representatives,
            'catTitle'          =>  Category::findOrFail($catId)->title
        ];

        return view('admin.ad.all', $dataView);
    }

    public function filterAds($memberId)
    {
        $ads = Ad::where('rep_id', $memberId)->get();
        $representatives    = Member::where('level', 2)->get();
        $dataView           =   [
            'ads'               =>  $ads,
            'counter'           =>  0,
            'representatives'   =>  $representatives
        ];

        return view('admin.ad.all', $dataView);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories         =   Category::all();
        $cities             =   City::all();
        $representatives    =   Member::where('level', 2)->get();

        $dataView           =   [
            'categories'        =>  $categories,
            'cities'            =>  $cities,
            'representatives'   =>  $representatives
        ];

        return view('admin.ad.add', $dataView);
    }

    /**
     * @param CreateAdRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(CreateAdRequest $request)
    {
         $ad = new Ad();

         if($request->period == 'other_period')            $request->period    = $request->period_other_period;
         if($request->offer == 'percent_discount_choose')  $request->offer     = $request->percent_discount;
         if($request->offer == 'discount_to_choose')       $request->offer     = "< $request->discount_to";

         $ad->title              =   $request->title;
         $ad->date               =   \Carbon\Carbon::now()->toDateString();
         $ad->time               =   \Carbon\Carbon::now()->toTimeString();
         $ad->day                =   date('l');
         $ad->rep_id             =   $request->representative;
         $ad->description        =   $request->description;
         $ad->number             =   $request->number;
         $ad->phone              =   $request->phone;
         $ad->mobile             =   $request->mobile;
         $ad->email              =   $request->email;
         $ad->website            =   $request->website;
         $ad->cat_id             =   $request->category;
         $ad->period             =   $request->period;
         $ad->offer              =   $request->offer;
         $ad->city_id            =   $request->city;
         $ad->position           =   $request->position;
         $ad->address            =   $request->address;
         $ad->lat                =   $request->longitude;
         $ad->lng                =   $request->latitude;
         $ad->is_featured        =   $request->is_featured;

         try {
             if ($ad->save()) {
                 if ($request->pic1) {
                     $request->file('pic1')
                         ->move(public_path('uploads/' . $ad->id), '1.jpg');
                 }

                 if ($request->pic2) {
                     $request->file('pic2')
                         ->move(public_path('uploads/' . $ad->id), '2.jpg');
                 }

                 if ($request->pic3) {
                     $request->file('pic3')
                         ->move(public_path('uploads/' . $ad->id), '3.jpg');
                 }

                 if ($request->pic4) {
                     $request->file('pic4')
                         ->move(public_path('uploads/' . $ad->id), '4.jpg');
                 }

                 if ($request->pic5) {
                     $request->file('pic5')
                         ->move(public_path('uploads/' . $ad->id), '5.jpg');
                 }
             }
             return redirect()->back()->with('message','تم إضافة الإعلان بنجاح ');
         } catch (ParseException $ex) {
             echo 'خطأ فى إضافة الإعلان من فضلك قم بمراجعته مرة اخرى';
         }
    }

    public function postUpload()
    {
        $form_data = \Input::all();
        $photo = $form_data['img'];


        $allowed_filename = 'pic';

        $filename_ext = $allowed_filename .'.jpg';

        $manager = new ImageManager();
        $image = $manager->make( $photo )->encode('jpg')->save(env('UPLOAD_PATH') . $filename_ext );

        if( !$image) {
            return \Response::json([
                'status' => 'error',
                'message' => 'Server error while uploading',
            ], 200);
        }

        return \Response::json([
            'status'    => 'success',
            'url'       => env('URL').'uploads/'. $filename_ext,
            'width'     => $image->width(),
            'height'    => $image->height()
        ], 200);
    }

    public function postCrop()
    {
        $form_data = \Input::all();
        $image_url = $form_data['imgUrl'];

        // resized sizes
        $imgW = $form_data['imgW'];
        $imgH = $form_data['imgH'];
        // offsets
        $imgY1 = $form_data['imgY1'];
        $imgX1 = $form_data['imgX1'];
        // crop box
        $cropW = '600';
        $cropH = '400';

        // rotation angle
        $angle = $form_data['rotation'];

        $filename_array = explode('/', $image_url);
        $filename = $filename_array[sizeof($filename_array)-1];

        $manager = new ImageManager();
        $image = $manager->make( $image_url );
        $image->resize($imgW, $imgH)
            ->rotate(-$angle)
            ->crop($cropW, $cropH, $imgX1, $imgY1)
            ->save(env('UPLOAD_PATH') . 'cropped-' . $filename);

        if( !$image) {
            return \Response::json([
                'status' => 'error',
                'message' => 'Server error while uploading',
            ], 200);

        }

        return \Response::json([
            'status' => 'success',
            'url' => env('URL') . 'uploads/cropped-' . $filename
        ], 200);
    }



    public function search()
    {
        $categories = 	Category::all();
        $cities 	=	City::all();

        $query		=	"";
        $ads 		= 	array();
        $title 		=	\Input::get('title');
        $city 		=	\Input::get('city');
        $position 	=	\Input::get('position');
        $category 	=	\Input::get('category');
        $number 	=	\Input::get('number');

        $query = Ad::select('id','title', 'city_id', 'position', 'cat_id', 'number','visits');

        if ($title) {
            $query->where('title', 'LIKE', '%'.$title.'%');
        }

        if ($city) {
            $query->where('city_id', '=', $city);
        }

        if ($position) {
            $query->where('position', '=', $position);
        }

        if ($category) {
            $query->where('cat_id', '=', $category);
        }

        if ($number) {
            $query->where('number', '=', $number);
        }

        $ads = $query->orderBy('id', 'DESC')->get();

        $representatives	=	Member::where('level', '=', 2)->get();
        $counter 	=	1;
        return view('admin.ad.all')
            ->with('ads', $ads)
            ->with('counter', $counter)
            ->with('representatives', $representatives)
            ->with('categories', $categories)
            ->with('cities', $cities);

    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $ad = Ad::findOrFail($id);
        $dataView           =   [
            'ad'                =>  $ad,
        ];
        return view('admin.ad.single', $dataView);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $ad                 =   Ad::findOrFail($id);
        $categories         =   Category::all();
        $cities             =   City::all();
        $representatives    =   Member::where('level', 2)->get();

        $dataView           =   [
            'ad'                =>  $ad,
            'categories'        =>  $categories,
            'cities'            =>  $cities,
            'representatives'   =>  $representatives
        ];
        return view('admin.ad.edit', $dataView);
    }

    /**
     * @param UpdateAdRequest $request
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateAdRequest $request, $id)
    {
        $ad =  Ad::findOrFail($id);

        if($request->period == 'other_period')            $request->period    = $request->period_other_period;
        if($request->offer == 'percent_discount_choose')  $request->offer     = $request->percent_discount;
        if($request->offer == 'discount_to_choose')       $request->offer     = "< $request->discount_to";

        $ad->title              =   $request->title;
        $ad->date               =   \Carbon\Carbon::now()->toDateString();
        $ad->time               =   \Carbon\Carbon::now()->toTimeString();
        $ad->day                =   date('l');
        $ad->rep_id             =   $request->representative;
        $ad->description        =   $request->description;
        $ad->phone              =   $request->phone;
        $ad->mobile             =   $request->mobile;
        $ad->email              =   $request->email;
        $ad->website            =   $request->website;
        $ad->cat_id             =   $request->category;
        $ad->period             =   $request->period;
        $ad->offer              =   $request->offer;
        $ad->city_id            =   $request->city;
        $ad->position           =   $request->position;
        $ad->address            =   $request->address;
        $ad->lat                =   $request->longitude;
        $ad->lng                =   $request->latitude;
        $ad->is_featured        =   $request->is_featured;

        try {
            if ($ad->save()) {
                if ($request->pic1) {
                    $request->file('pic1')
                        ->move(public_path('uploads/' . $ad->id), '1.jpg');
                }

                if ($request->pic2) {
                    $request->file('pic2')
                        ->move(public_path('uploads/' . $ad->id), '2.jpg');
                }

                if ($request->pic3) {
                    $request->file('pic3')
                        ->move(public_path('uploads/' . $ad->id), '3.jpg');
                }

                if ($request->pic4) {
                    $request->file('pic4')
                        ->move(public_path('uploads/' . $ad->id), '4.jpg');
                }

                if ($request->pic5) {
                    $request->file('pic5')
                        ->move(public_path('uploads/' . $ad->id), '5.jpg');
                }
            }
            return redirect()->back()->with('message','تم تعديل الإعلان بنجاح');
        } catch (ParseException $ex) {
            echo 'خطأ فى تعديل الإعلان ، من فضلك قم بمراجعته مرة اخرى';
        }
    }

    public function deleteGroup()
    {
        $selected_ads 	=   \Input::get('to_delete');
        if (!empty($selected_ads)) {
            try {
                Ad::whereIn('id', $selected_ads)->delete();
                foreach($selected_ads as $ad)
                {
                    $this->deletePicsFolder($ad);
                }
            } catch (ParseException $ex) {
                echo 'خطأ فى حذف الإعلانات ، من فضلك قم بالمراجعة مرة اخرى';
            }
            return \Redirect::route('admin.ad.index');

        }
        return \Redirect::route('admin.ad.index');
    }

    public function deletePicsFolder($id)
    {
        try {
            \File::delete(public_path('uploads/'.$id), true);
        } catch (ParseException $ex) {
            echo 'خطأ فى حذف صور الإعلانات ، من فضلك قم بالمراجعة مرة اخرى';
        }
    }

    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
