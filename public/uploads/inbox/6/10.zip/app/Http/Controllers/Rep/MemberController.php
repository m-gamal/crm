<?php

namespace App\Http\Controllers\Rep;

use App\Http\Requests;

use App\Http\Controllers\Controller;
use App\Http\Requests\Rep\LoginRequest;

class MemberController extends Controller
{
    public function login()
    {
        return view('rep.login');
    }

    public function doLogin(LoginRequest $request)
    {
        if (\Auth::attempt(['username' => $request->username, 'password' => $request->password, 'level'=>'2'],
            $request->remember_me)) {
            // Authentication passed...
            return redirect()->intended('rep/ad');
        }
        return redirect()->route('repLogin')->with('login-error', 'قم بتأكد من بيانات تسجيل الدخول');;
    }

    public function doLogout()
    {
        \Auth::logout();
        return redirect()->route('repLogin');
    }
}