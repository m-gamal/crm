<?php

namespace App\Http\Controllers\Admin;

use App\Category;
use Illuminate\Http\Request;
use App\Http\Requests\Admin\CategoryRequest;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = Category::all();
        $dataView   =   [
            'categories'    =>  $categories
        ];
        return view('admin.category.all', $dataView);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * @param Requests\Admin\CategoryRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(CategoryRequest $request)
    {
        $category = new Category;
        $category->title = $request->title;

        try {
            $category->save();
            return redirect()->back()->with('message','تم إضافة الفئة بنجاح ');
        } catch (ParseException $ex) {
            echo 'خطأ فى إضافة الفئة ، من فضلك قم بالمراجعة مرة اخرى';
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * @param CategoryRequest $request
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(CategoryRequest $request, $id)
    {
        $singleCategory = Category::findOrFail($id);
        $singleCategory->title = $request->title;
        try {
            $singleCategory->save();
            return redirect()->back()->with('message','تم تعديل الفئة بنجاح');
        } catch (ParseException $ex) {
            echo 'خطا فى تعديل الفئة ، من فضلك قم بالمراجعة مرة اخرى';
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $singleCategory = Category::findOrFail($id);
        try {
            $singleCategory->delete();
            return redirect()->back()->with('message','تم حذف الفئة بنجاح');
        } catch (ParseException $ex) {
            echo 'خطأ فى حذف الفئة ، من فضلك قم بالمراجعة مرة اخرى';
        }
    }
}
