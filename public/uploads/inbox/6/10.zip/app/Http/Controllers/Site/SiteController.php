<?php

namespace App\Http\Controllers\Site;

use App\Ad;
use App\Category;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Visit;
use App\Http\Requests\Site\ContactRequest;

class SiteController extends Controller
{
    public function home()
    {
        $latest             =   Ad::orderBy('created_at', 'desc')->take(4)->get();
        $mostViewed         =   Ad::orderBy('visits', 'desc')->take('5')->get();
        $ads                =   Ad::where('is_featured', 1)->get();
        $freeAds            =   Ad::where('is_featured', 0)->get();
        $threeCategories    =   [];
        foreach(Category::take(3)->get() as $singleCategory)
        {
            $threeCategories[$singleCategory->title]   =   Ad::where('cat_id', $singleCategory->id)->take(5)->get();
        }

        $dataView = [
            'featuredAds'       =>  $ads,
            'threeCategories'   =>  $threeCategories,
            'latest'            =>  $latest,
            'mostViewed'        =>  $mostViewed,
            'freeAds'           =>  $freeAds
        ];

        return view('site/index', $dataView);
    }

    public function catAds($catId)
    {
        $ads                = Ad::where('cat_id', $catId)->get();

        $dataView           =   [
            'ads'               =>  $ads,
            'catTitle'          =>  Category::findOrFail($catId)->title
        ];

        return view('site.ads_type', $dataView);
    }

    public function search()
    {
        $title 		=	\Input::get('title');
        $city 		=	\Input::get('city');
        $position 	=	\Input::get('position');
        $category 	=	\Input::get('category');

        $query = Ad::select('id','title', 'city_id', 'position', 'cat_id','visits', 'offer');

        if ($title){
            $query->where('title', 'LIKE', '%'.$title.'%');
        }

        if ($city) {
            $query->where('city_id', '=', $city);
        }

        if ($position) {
            $query->where('position', '=', $position);
        }

        if ($category) {
            $query->where('cat_id', '=', $category);
        }

        $ads = $query->orderBy('id', 'DESC')->get();


        return view('site.ads_search')->with('ads', $ads);
    }

    public function adShow($id)
    {
        $ad         =   Ad::findOrFail($id);
        $ip 		= 	$_SERVER["REMOTE_ADDR"];
        $user_agent	=	$_SERVER["HTTP_USER_AGENT"];

        $visitsCount 	=	Visit::where('ip', '=', $ip)
                                ->where('user_agent', '=', $user_agent)
                                ->where('ad_id', '=', $id)
                                ->count();

        if ($visitsCount == 0){
            $visits 				=	new Visit();
            $visits->ip 			= 	$ip;
            $visits->user_agent 	=	$user_agent;
            $visits->ad_id 		    =	$id;
            if ($visits->save()){
                $ad->visits				+= 	1;
                $ad->save();
            }
        }

        $dataView   =   [
            'ad'    =>  $ad,
        ];

        return view('site.single', $dataView);
    }

    public function nearbyAds()
    {
        $location   =   \GeoIP::getLocation();

        $ads = \DB::select(\DB::raw('SELECT id,rep_id, title, day, time, description,phone, offer, mobile, website, number,date,cat_id, period, position,address, is_featured, visits,
		 ( 3959 * acos( cos( radians(' . $location['lat'] . ') ) * cos( radians( lat ) ) * cos( radians( lng ) - radians(' . $location['lon'] . ') ) + sin( radians(' . $location['lat'] .') ) * sin( radians(lat) ) ) ) AS distance FROM ad ORDER BY distance') );

        $dataView   =   [
            'ads'    =>  $ads,
        ];

        return view('site.ads_type', $dataView);
    }

    public function siteSpecialAds()
    {
        $specialAds = Ad::where('offer', 'special_choose')->get();
        $dataView   =   [
            'specialAds'    =>  $specialAds,
        ];

        return view('site.sales', $dataView);
    }

    public function contact()
    {
        return view('site.contact');
    }

    public function doContact(ContactRequest $request)
    {

    }
}
