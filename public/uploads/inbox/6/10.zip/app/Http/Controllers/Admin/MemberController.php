<?php

namespace App\Http\Controllers\Admin;

use App\Member;
use App\Http\Requests\Admin\CreateMemberRequest;
use App\Http\Requests\Admin\UpdateMemberRequest;
use App\Http\Requests\Admin\UpdatePasswordRequest;
use App\Http\Requests\Admin\LoginRequest;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Ad;

class MemberController extends Controller
{
    public function login()
    {
        return view('admin.login');
    }

    public function doLogin(LoginRequest $request)
    {
        if (\Auth::attempt(['username' => $request->username, 'password' => $request->password, 'level'=>'1'],
            $request->remember_me)) {
            // Authentication passed...
            return redirect()->intended('admin/member');
        }
        return redirect()->route('adminLogin')->with('login-error', 'قم بتأكد من بيانات تسجيل الدخول');
    }

    public function doLogout()
    {
        \Auth::logout();
        return redirect()->route('adminLogin');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $representatives        = Member::where('level', 2)->get();
        $dataView               =   [
            'representatives'   =>  $representatives
        ];
        return view('admin.member.all', $dataView);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.member.add');
    }

    /**
     * @param CreateMemberRequest $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(CreateMemberRequest $request)
    {
        $member = new Member;
        $member->full_name  = $request->full_name;
        $member->username   = $request->username;
        $member->email      = $request->email;
        $member->password   = \Hash::make($request->password);
        $member->level      = 2;
        try {
            $member->save();
            return redirect()->back()->with('message','تم إضافة المندوب بنجاح ');
        } catch (ParseException $ex) {
            echo 'خطأ فى إضافة المندوب ، من فضلك قم بالمراجعة مرة اخرى';
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $representative         =   Member::findOrFail($id);
        $dataView               =   [
            'representative'   =>  $representative
        ];
        return view('admin.member.show', $dataView);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $representative         =   Member::findOrFail($id);
        $dataView               =   [
            'representative'   =>  $representative
        ];
        return view('admin.member.edit', $dataView);
    }

    /**
     * @param UpdateMemberRequest $request
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */

    public function update(UpdateMemberRequest $request, $id)
    {
        $singleMember               = Member::findOrFail($id);
        $singleMember->full_name    = $request->full_name;
        $singleMember->username     = $request->username;
        $singleMember->email        = $request->email;
        $singleMember->level        = 2;
        try {
            $singleMember->save();
            return redirect()->route('admin.member.index')->with('message','تم تعديل المندوب بنجاح');
        } catch (ParseException $ex) {
            echo 'خطا فى تعديل المندوب ، من فضلك قم بالمراجعة مرة اخرى';
        }
    }

    public function changePassword(UpdatePasswordRequest $request, $id)
    {
        $singleMember = Member::findOrFail($id);
        $singleMember->password = \Hash::make($request->password);
        try {
            $singleMember->save();
            return redirect()->route('admin.member.index')->with('message','تم تعديل كلمة المرور بنجاح');
        } catch (ParseException $ex) {
            echo 'خطأ فى تعديل كلمة المرور ، من فضلك قم بالمراجعة مرة اخرى';
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $singleMember = Member::findOrFail($id);
        try {
            $singleMember->delete();
            return redirect()->back()->with('message','تم حذف المندوب بنجاح');
        } catch (ParseException $ex) {
            echo 'خطأ فى حذف المندوب ، من فضلك قم بالمراجعة مرة اخرى';
        }
    }


    public function repAds($id)
    {
        $representatives    = Member::where('level', 2)->get();


        $ads = Ad::where('rep_id', $id)->get();

        $dataView           =   [
            'ads'               =>  $ads,
            'counter'           =>  0,
            'representatives'   =>  $representatives,
        ];

        return view('admin.ad.all', $dataView);
    }
}
