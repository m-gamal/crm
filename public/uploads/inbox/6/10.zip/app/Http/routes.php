<?php
use App\Ad;
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// Site Section
Route::get('/', ['as'   =>    'home', 'uses'  =>  'Site\SiteController@home']);
Route::post('search', ['as'=> 'siteSearch', 'uses'  =>  'Site\SiteController@search']);
Route::get('category-ads/{id}', ['as'=> 'siteCatAds', 'uses'  =>  'Site\SiteController@catAds']);
Route::get('show/{id}', ['as'=> 'siteAdShow', 'uses'  =>  'Site\SiteController@adShow']);
Route::get('special', ['as'=> 'siteSpecialAds', 'uses'  =>  'Site\SiteController@siteSpecialAds']);
Route::get('nearby', ['as'=> 'nearbyAds', 'uses'  =>  'Site\SiteController@nearbyAds']);
Route::get('contact', ['as'=> 'contact', 'uses'  =>  'Site\SiteController@contact']);
Route::post('contact', ['as'=> 'doContact', 'uses'  =>  'Site\SiteController@doContact']);

Route::post('/upload', ['as'=> 'upload', 'uses'  =>  'Admin\AdController@postUpload']);
Route::post('/crop', ['as'=> 'crop', 'uses'  =>  'Admin\AdController@postCrop']);


Route::get('admin/login', ['as'=> 'adminLogin', 'uses'  =>  'Admin\MemberController@login']);
Route::post('admin/login', ['as'=> 'doAdminLogin', 'uses'  =>  'Admin\MemberController@doLogin']);
Route::get('admin/logout', ['as'=> 'adminLogout', 'uses'  =>  'Admin\MemberController@doLogout']);

Route::get('rep/login', ['as'=> 'repLogin', 'uses'  =>  'Rep\MemberController@login']);
Route::post('rep/login', ['as'=> 'doRepLogin', 'uses'  =>  'Rep\MemberController@doLogin']);
Route::get('rep/logout', ['as'=> 'repLogout', 'uses'  =>  'Rep\MemberController@doLogout']);

// Admin Section
Route::group(
[
    'prefix'        => 'admin/',
    'middleware'    => 'admin',
],
function()
{
    Route::resource('ad', 'Admin\AdController');
    Route::resource('category', 'Admin\CategoryController');
    Route::resource('city', 'Admin\CityController');
    Route::resource('member', 'Admin\MemberController');
    Route::get('rep-ads/{id}', ['as'=> 'repAds', 'uses'  =>  'Admin\MemberController@repAds']);
    Route::post('change-password/{id}', ['as'    =>  'changePassword', 'uses'  =>  'Admin\MemberController@changePassword']);
    Route::get('filter-ads/{id}', ['uses'  =>  'Admin\AdController@filterAds']);
    Route::get('cat-ads/{id}', ['as'=>  'catAds', 'uses'  =>  'Admin\AdController@catAds']);
    Route::post('search', ['as'=> 'search', 'uses'  =>  'Admin\AdController@search']);
    Route::post('delete-group', ['as'	=> 'deleteGroup', 'uses'	=>	'Admin\AdController@deleteGroup']);
});
// Rep Section
Route::group(
[
    'prefix'        => 'rep/',
    'middleware'    => 'rep',
],
function()
{
    Route::resource('ad', 'Rep\AdController');
    Route::get('cat-ads/{id}', ['as'=>  'repCatAds', 'uses'  =>  'Rep\AdController@catAds']);
    Route::post('search', ['as'=> 'repSearch', 'uses'  =>  'Rep\AdController@search']);
});