<?php

namespace App\Http\Controllers\MR;

use App\Http\Requests\MR\LoginRequest;
use App\Http\Controllers\Controller;

class AuthController extends Controller
{
    public function login()
    {
        return view('mr.login');
    }

    public function doLogin(LoginRequest $request)
    {
        if (\Auth::attempt(['email' => $request->email, 'password' => $request->password, 'active'=>'1'],
            $request->remember_me)) {
            return redirect()->intended('mr/dashboard');
        }
        return redirect()->route('mrLogin')->with('login-error', 'Please Check your login data !');
    }

    public function doLogout()
    {
        \Auth::logout();
        return redirect()->route('mrLogin');
    }
}
