<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Message;
use App\MessageReply;
use App\SMLeaveRequest;
use App\SMServiceRequest;
use App\SMPlan;
use View;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
//        if(\Auth::check()) { // if user logged
        $allUnread  =   MessageReply::select('msg_id')->where('is_read', 0)->get();
        $unread     =   Message::whereIn('id', $allUnread)->where('receiver', 3)->get();

        $smPendingRequests = 0;
        $smPendingPlans = $this->getSMPendingPlans();
        $smPendingLeaveRequests = $this->getSMPendingLeaveRequests();
        $smPendingServicesRequests = $this->getSMPendingServicesRequests();

        if ($smPendingPlans != 0
            || $smPendingLeaveRequests != 0
            || $smPendingServicesRequests != 0
        ) {

            $smPendingRequests = 1;
        }

        View::share('unread', $unread);
        View::share('testVar', 'testVar');
        View::share('smPendingRequests', $smPendingRequests);
        View::share('smCountPendingPlans', $smPendingPlans);
        View::share('smCountPendingLeaveRequests', $smPendingLeaveRequests);
        View::share('smCountPendingServicesRequest', $smPendingServicesRequests);
//        }
    }

        // Sales Manager
        public function getSMPendingPlans(){
        $plans = SMPlan::pending()->get();
        return count($plans);
    }

        public function getSMPendingLeaveRequests(){
        $leaveRequests  = SMLeaveRequest::pending()->get();
        return count($leaveRequests);
    }

        public function getSMPendingServicesRequests(){
        $serviceRequests    = SMServiceRequest::pending()->get();
        return count($serviceRequests);
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
